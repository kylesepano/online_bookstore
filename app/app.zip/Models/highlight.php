<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class highlight extends Model
{
    use HasFactory;

    protected $fillable = [
        'message_id',
        'time_stamp',
        'description'
    ];
}
