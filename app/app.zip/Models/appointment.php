<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class appointment extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'staff_id',
        'date',
        'status',
        'description',
        'user_message_id',
        'staff_message_id',
    ];

    public function staff()
    {
        return $this->belongsTo(user::class, 'staff_id');
    }
    public function user()
    {
        return $this->belongsTo(user::class, 'user_id');
    }
    public function messages()
    {
        return $this->hasMany(messages::class, 'appointment_id');
    }
    public function appointment_users()
    {
        return $this->hasMany(appointment_user::class, 'appointment_id');
    }
    public function stat()
    {
        if ($this->status == 0) {
            return "Rejected";
        } elseif ($this->status == 1) {
            return "Pending";
        } elseif ($this->status == 2) {
            return "Ongoing";
        } else {
            return "Done";
        }
    }

    public function message()
    {
        if (messages::where('appointment_id', $this->id)->latest() != null) {
            return messages::where('appointment_id', $this->id)->latest()->first();
        } else {
            return null;
        }
    }
}
