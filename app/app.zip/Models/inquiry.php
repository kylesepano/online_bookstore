<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class inquiry extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'staff_id',
        'status',
        'user_message_id',
        'staff_message_id',
    ];
    public function inquiry_messages()
    {
        return $this->hasMany(inquiry_messages::class, 'inquiry_id')->orderBy('created_at', 'desc');
    }
    public function user()
    {
        return $this->belongsTo(user::class, 'user_id');
    }
    public function message()
    {
        return inquiry_messages::where('inquiry_id', $this->id)->latest()->first();
    }
}
