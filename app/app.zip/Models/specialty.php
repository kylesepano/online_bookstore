<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class specialty extends Model
{
    use HasFactory;
    protected $fillable = [
        'specialty',
        'description',
        'specialty_code',
        'status',
    ];
    public function employee_specialties()
    {
        return $this->hasMany(employee_specialty::class, 'specialty_id');
    }
}
