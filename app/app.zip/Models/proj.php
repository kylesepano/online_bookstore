<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class proj extends Model
{

    protected $fillable = [
        'name',
        'location'
    ];
    public function images()
    {
        return $this->hasMany(project_image::class, 'project_id');
    }
}
