<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class tool extends Model
{
    use HasFactory;
    protected $fillable = [
        'name',
        'description',
        'price_start',
        'price_end',
        'equipment_code',
        'image',
        'type_id',
        'status',
    ];

    public function type()
    {
        return $this->belongsTo(type::class, 'type_id');
    }
    public function price()
    {
        return 'PHP ' . $this->price_start . ' - PHP' .  $this->price_end;
    }
    public function tool_suppliers()
    {
        return $this->hasMany(tool_supplier::class, 'tool_id');
    }
}
