<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class tool_supplier extends Model
{
    use HasFactory;
    protected $fillable = [
        'tool_id',
        'supplier_id',
        'price'
    ];

    public function tool()
    {
        return $this->belongsTo(tool::class, 'tool_id');
    }
    public function supplier(){
        return $this->belongsTo(supplier::class,'supplier_id');
    }
}
