<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use PDO;

class user extends Authenticatable
{
    use HasFactory;

    protected $fillable = [
        'username',
        'password',
        'user_type',
        'status',
        'mname',
        'fname',
        'lname',
        'address',
        'contact_number',
        'email',
        'profile',
    ];

    public function fullname()
    {
        return $this->lname . ', ' . $this->fname;
    }

    public function name()
    {
        return $this->lname . ' ' . ucfirst(substr($this->fname, 0, 1)) . '.';
    }

    public function services()
    {
        return $this->hasMany(employee_service::class, 'user_id');
    }
    public function specialties()
    {
        return $this->hasMany(employee_specialty::class, 'user_id');
    }

    public function type()
    {
        if ($this->user_type == 1) {
            return "Admin";
        } elseif ($this->user_type == 2) {
            return "Staff";
        } elseif ($this->user_type == 3) {
            return "Engineer";
        } else {
            return "User";
        }
    }
    public function engineer_appointents()
    {
        return appointment::whereIn('id', appointment_user::where('user_id', $this->id)->pluck('appointment_id')->toArray())->where(function ($e) {
            $e->where('status', 1)->orWhere('status', 2);
        })->get();
    }
    public function user_appointments()
    {
        return appointment::where('user_id', $this->id)->where(function ($e) {
            $e->where('status', 1)->orWhere('status', 2);
        })->get();
    }
    public function staff_appointments()
    {
        return appointment::where('staff_id', $this->id)->where(function ($e) {
            $e->where('status', 1)->orWhere('status', 2);
        })->get();
    }
    public function staff_inquiries()
    {
        return inquiry::where('staff_id', $this->id)->where(function ($e) {
            $e->where('status', 1);
        })->get();
    }


    public function inquiry_user()
    {
        return inquiry::where('user_id', $this->id)->where('status', 1)->latest()->first();
    }

    public function notification_messages()
    {
        $notifications = [];
        $x = 0;
        if ($this->user_type == 2) {
            foreach ($this->staff_inquiries() as $i) {
                if ($i->message()) {
                    if ($i->message()->user_id != $this->id && $i->message()->id != $i->staff_message_id) {
                        $notifications[$x] = ['Helpdesk', $i->id, $i->message()->message, 1, $i->message()->user->fullname()];
                        $x += 1;
                    }
                }
            }
            foreach ($this->staff_appointments() as $a) {
                if ($a->message()) {
                    if ($a->message()->user_id != $this->id && $a->message()->id != $a->staff_message_id) {
                        $notifications[$x] = ['Appointment', $a->id, $a->message()->message, $a->message()->type, $a->message()->user->fullname()];
                        $x += 1;
                    }
                }
            }
        } elseif ($this->user_type == 3) {
            foreach ($this->engineer_appointents() as $a) {
                if ($a->message()) {
                    $message_id = appointment_user::where('user_id', $this->id)->where('appointment_id', $a->id)->first()->message_id;
                    if ($a->message()->user_id != $this->id && $a->message()->id != $message_id) {
                        $notifications[$x] = ['Appointment', $a->id, $a->message()->message, $a->message()->type, $a->message()->user->fullname()];
                        $x += 1;
                    }
                }
            }
        } elseif ($this->user_type == 4) {
            foreach ($this->user_appointments() as $a) {
                if ($a->message()) {
                    if ($a->message()->user_id != $this->id && $a->message()->id != $a->user_message_id) {
                        $notifications[$x] = ['Appointment', $a->id, $a->message()->message, $a->message()->type, $a->message()->user->fullname()];
                        $x += 1;
                    }
                }
            }
            if ($this->inquiry_user() != null && $this->inquiry_user()->message() != null) {
                if ($this->inquiry_user()->message()->user_id != $this->id && $this->inquiry_user()->message()->id != $this->inquiry_user()->user_message_id) {
                    $notifications[$x] = ['Helpdesk', $this->inquiry_user()->message()->id, $this->inquiry_user()->message()->messsage, 1, $this->inquiry_user()->message()->user->fullname()];
                }
            }
        }
        return $notifications;
    }
    public function notification_helps()
    {
        $notifications = [];
        $x = 0;
        $appointments  = appointment::where('staff_id', null)->get();
        $inquries = inquiry::where('staff_id', null)->where('status','!=',2)->get();
        foreach ($inquries as $a) {
            $notifications[$x] = ['Helpdesk', $a->id, $a->user->fullname()];
            $x += 1;
        }
        foreach ($appointments as $a) {
            $notifications[$x] = ['Appointment', $a->id, $a->user->fullname(), $a->date];
            $x += 1;
        }

        return $notifications;
    }
}
