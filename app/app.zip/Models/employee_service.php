<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class employee_service extends Model
{
    use HasFactory;
    protected $fillable = [
        'user_id',
        'service_id',

    ];

    public function user()
    {
        return $this->belongsTo(user::class, 'user_id');
    }
    public function service()
    {
        return $this->belongsTo(service::class, 'service_id');
    }
}
