<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use PDO;

class messages extends Model
{
    use HasFactory;

    public $fillable = [
        'message',
        'user_id',
        'appointment_id',
        'type',
        'description',
    ];

    public function user()
    {
        return $this->belongsTo(user::class, 'user_id');
    }
    public function tool()
    {
        return $this->belongsTo(tool::class, 'message');
    }
    public function highlights()
    {
        return $this->hasMany(highlight::class, 'message_id');
    }
}
