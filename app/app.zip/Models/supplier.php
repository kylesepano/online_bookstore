<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class supplier extends Model
{
    use HasFactory;
    protected $fillable = [
        'name',
        'address',
        'contact_number',
        'email',
        'status',
        'profile',
    ];
    public function tool_suppliers()
    {
        return $this->hasMany(tool_supplier::class, 'supplier_id');
    }
    public function supplier_contacts()
    {
        return $this->hasMany(supplier_contact::class, 'supplier_id');
    }
}
