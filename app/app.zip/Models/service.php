<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class service extends Model
{
    use HasFactory;
    protected $fillable = [
        'service',
        'description',
        'service_code',
        'status'
    ];
    public function employee_services()
    {
        return $this->hasMany(employee_service::class, 'service_id');
    }
}
