<?php

namespace App\Http\Livewire;

use App\Models\appointment;
use App\Models\appointment_user;
use App\Models\highlight;
use App\Models\messages;
use App\Models\tool;
use App\Models\user;
use Livewire\Component;
use Livewire\WithPagination;
use Livewire\WithFileUploads;

class AppointmentShow extends Component
{
    use WithPagination;
    use WithFileUploads;
    public $message;
    public $appointment;
    protected $paginationTheme = 'bootstrap';
    public $message_stat = 0;
    public $chat;
    public $equipment;
    public $file_up;
    public $description;
    public $type = 1;
    public $tools = [];
    public $tools_check;
    public $messages = [];
    public $equipments = [];
    public $filter = "All";
    public $employees = [];
    public $employee_id = "";
    public $highlight;
    public $time_stamp;
    public $h_description;
    public function mount($id)
    {
        if ($id != 0) {
            $this->message_stat = 1;
            $this->appointment = appointment::find($id);
        }
    }
    public function render()
    {
        if (auth()->user()->user_type == 1 || auth()->user()->user_type == 2) {
            $appointments = appointment::paginate(10);
        } elseif (auth()->user()->user_type == 4) {
            $appointments = appointment::where('user_id', auth()->user()->id)->paginate(10);
        } else {
            $appointments = appointment::whereIn('id', appointment_user::where('user_id', auth()->user()->id)->pluck('appointment_id')->toArray())->paginate(10);
        }
        $this->tools_check = false;
        foreach ($this->tools as $t) {
            if ($t) {
                $this->tools_check = true;
            }
        }
        if ($this->message_stat == 1) {
            if ($this->appointment != null) {
                $latest = messages::where('appointment_id', $this->appointment->id)->latest()->first();
                if ($latest != null) {
                    if (auth()->user()->user_type == 4) {
                        $this->appointment->user_message_id = $latest->id;
                        $this->appointment->save();
                    } elseif (auth()->user()->user_type == 2) {
                        $this->appointment->staff_message_id = $latest->id;
                        $this->appointment->save();
                    } elseif (auth()->user()->user_type == 3) {
                        $user = appointment_user::where('appointment_id', $this->appointment->id)->where('user_id', auth()->user()->id)->first();
                        if ($user != null) {
                            $user->message_id = $latest->id;
                            $user->save();
                        }
                    }
                }
            }
        }
        $this->dispatchBrowserEvent('data_table');
        return view('livewire.appointment-show', ['appointments' => $appointments]);
    }
    public function ref()
    {
        $this->chat = null;
        $this->tools = [];
        $this->file_up = null;
        $this->filter = "All";
        $this->description = null;
        $this->message = null;
    }
    public function employee_show($id)
    {
        $this->appointment = appointment::find($id);
        $this->employee_id = "";
        $this->employees = user::where('user_type', 3)->where('status', 1)->whereNotIn('id', appointment_user::whereIn('appointment_id', appointment::where('date', $this->appointment->date)->where('status', 2)->pluck('id')->toArray())->pluck('user_id')->toArray())->whereNotIn('id', appointment_user::where('appointment_id', $this->appointment->id)->pluck('user_id')->toArray())->get();
        $this->dispatchBrowserEvent('employee_show');
    }
    public function approve_show($id)
    {
        $this->appointment = appointment::find($id);
        $this->dispatchBrowserEvent('approve_show');
    }
    public function approve()
    {
        $this->appointment->status = 2;
        $this->appointment->staff_id = auth()->user()->id;
        $this->appointment->save();
        $this->message = "Successfully Approved Appointment";
        $this->dispatchBrowserEvent('approve_show');
    }
    public function reject_show($id)
    {
        $this->appointment = appointment::find($id);
        $this->dispatchBrowserEvent('reject_show');
    }
    public function done_show($id)
    {
        $this->appointment = appointment::find($id);
        $this->dispatchBrowserEvent('done_show');
    }
    public function reject()
    {
        $this->appointment->status = 0;
        $this->appointment->staff_id = auth()->user()->id;
        $this->appointment->save();
        $this->message = "Successfully Rejected Appointment";
        $this->dispatchBrowserEvent('reject_show');
    }
    public function done()
    {
        $this->appointment->status = 3;
        $this->appointment->save();
        $this->message = "Successfully Closed Appointment";
        $this->dispatchBrowserEvent('done_show');
    }

    public function message($id)
    {
        $this->message_stat = $id;
        $this->appointment = appointment::find($id);
        $this->messages = messages::where('appointment_id', $id)->orderBy('created_at', 'desc')->get();
    }
    public function back()
    {
        $this->message_stat = 0;
    }
    public function stat($id)
    {
        $this->ref();
        $this->type = $id;
    }
    public function equipment_show()
    {

        $this->equipments = tool::where('status', '!=', 0)->get();
        $this->dispatchBrowserEvent('equipment_show');
    }
    public function send()
    {
        if ($this->type == 1) {
            messages::create([
                'message' => $this->chat,
                'user_id' => auth()->user()->id,
                'appointment_id' => $this->appointment->id,
                'type' => $this->type,
                'description',
            ]);
        } elseif ($this->type == 2) {
            foreach ($this->tools as $e) {
                if ($e) {
                    messages::create([
                        'message' => $e,
                        'user_id' => auth()->user()->id,
                        'appointment_id' => $this->appointment->id,
                        'type' => $this->type,
                        'description' => $this->description,
                    ]);
                }
            }
        } elseif ($this->type == 3) {
            $name = "uploads/files/" . $this->file_up->getClientOriginalName();
            $this->file_up->storeAs('files', $this->file_up->getClientOriginalName(), 'profile');
            messages::create([
                'message' => $name,
                'user_id' => auth()->user()->id,
                'appointment_id' => $this->appointment->id,
                'type' => $this->type,
                'description' => $this->description,
            ]);
        } else {
            messages::create([
                'message' => $this->chat,
                'user_id' => auth()->user()->id,
                'appointment_id' => $this->appointment->id,
                'type' => $this->type,
                'description',
            ]);
        }
        $this->filt();
        $this->ref();
    }
    public function filt()
    {
        if ($this->filter === "All") {
            $this->messages = messages::where('appointment_id', $this->appointment->id)->orderBy('created_at', 'desc')->get();
        } else {
            $this->messages = messages::where('appointment_id', $this->appointment->id)->where('type', $this->filter)->orderBy('created_at', 'desc')->get();
        }
    }
    public function e_show($id)
    {
        $this->equipment = tool::find($id);
        $this->dispatchBrowserEvent('e_show');
    }
    public function remove_employee($id)
    {
        $employee = appointment_user::find($id);
        $holder = $employee->appointment_id;
        $employee->delete();
        $this->employees = user::where('user_type', 3)->where('status', 1)->whereNotIn('id', appointment_user::whereIn('appointment_id', appointment::where('date', $this->appointment->date)->where('status', 2)->pluck('id')->toArray())->pluck('user_id')->toArray())->whereNotIn('id', appointment_user::where('appointment_id', $this->appointment->id)->pluck('user_id')->toArray())->get();
        $this->appointment = appointment::find($holder);
    }
    public function add_employee()
    {
        if ($this->employee_id != null && $this->employee_id != "") {
            appointment_user::create([
                'user_id' => $this->employee_id,
                'appointment_id' => $this->appointment->id,
            ]);
            $this->appointment = appointment::find($this->appointment->id);
            $this->employee_id = "";
            $this->employees = user::where('user_type', 3)->where('status', 1)->whereNotIn('id', appointment_user::whereIn('appointment_id', appointment::where('date', $this->appointment->date)->where('status', 2)->pluck('id')->toArray())->pluck('user_id')->toArray())->whereNotIn('id', appointment_user::where('appointment_id', $this->appointment->id)->pluck('user_id')->toArray())->get();
        }
    }
    public function highlight_show($id)
    {
        $this->ref();
        $this->time_stamp = null;
        $this->h_description = null;
        $this->highlight = messages::find($id);
        $this->dispatchBrowserEvent('highlight_show');
    }

    public function higlight_create()
    {
        highlight::create([
            'message_id' => $this->highlight->id,
            'time_stamp' => $this->time_stamp,
            'description' => $this->h_description
        ]);
        $this->time_stamp = null;
        $this->h_description = null;
        $this->message = "Successfully Added Highlight";
    }
    public function delete_highlight($id)
    {
        $highlight = highlight::find($id);
        $highlight->delete();
    }
}
