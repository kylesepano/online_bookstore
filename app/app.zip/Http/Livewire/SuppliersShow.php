<?php

namespace App\Http\Livewire;

use App\Models\supplier;
use App\Models\supplier_contact;
use Livewire\Component;
use Livewire\WithFileUploads;
use Livewire\WithPagination;
use Illuminate\Support\Facades\File;

class SuppliersShow extends Component
{
    use WithPagination;
    protected $paginationTheme = 'bootstrap';
    use WithFileUploads;
    public $search = "";
    public $sort = 1;
    public $supplier;
    public $message;

    public $email;
    public $name;
    public $address;
    public $contact_number;
    public $profile;

    public $type = "Address";
    public $contact;

    public $path;
    public function render()
    {
        $this->contact = null;
        $this->dispatchBrowserEvent('data_table');
        $sort = "DESC";
        if ($this->sort == 2) {
            $sort = "ASC";
        }
        $suppliers = supplier::where('status', 1)->where(function ($e) {
            $e->where('name', 'like', '%' . $this->search . '%')->orWhere('address', 'like', '%' . $this->search . '%')->orWhere('contact_number', 'like', '%' . $this->search . '%')->orWhere('email', 'like', '%' . $this->search . '%');
        })->orderBy('created_at', $sort)->paginate(9);
        return view('livewire.suppliers-show', ['suppliers' => $suppliers]);
    }
    public function ref()
    {
        $this->message = null;
        $this->email = null;
        $this->name = null;
        $this->address = null;
        $this->contact_number = null;
        $this->profile = null;
        $this->type = "Address";
        $this->contact = null;
    }
    public function add_show()
    {
        $this->ref();
        $this->dispatchBrowserEvent('add_show');
    }
    public function edit_show($id)
    {
        $this->ref();
        $this->supplier = supplier::find($id);
        $this->name = $this->supplier->name;
        $this->email = $this->supplier->email;
        $this->address = $this->supplier->address;
        $this->contact_number = $this->supplier->contact_number;

        $this->dispatchBrowserEvent('edit_show');
    }
    public function supplier_show($id)
    {
        $this->supplier = supplier::find($id);
        $this->ref();
        $this->dispatchBrowserEvent('supplier_show');
    }
    public function contact_show($id)
    {
        $this->supplier = supplier::find($id);
        $this->ref();
        $this->dispatchBrowserEvent('contact_show');
    }
    public function delete_show($id)
    {
        $this->supplier = supplier::find($id);
        $this->ref();
        $this->dispatchBrowserEvent('delete_show');
    }
    public function create()
    {
        $this->validate([
            'name' => 'required|unique:suppliers',
            'email' => 'unique:suppliers',
            'contact_number' => 'max:255|unique:suppliers',
            'profile' => 'image|max:10000|nullable',
        ]);
           $name = null;
        $date = date('YmdHis');
        if ($this->profile != null) {
            $name = "uploads/supplier/" . $date . ".png";
            $this->profile->storeAs('supplier', $date . '.png', 'profile');
        }
        supplier::create([
            'name' => $this->name,
            'address' => $this->address,
            'contact_number' => $this->contact_number,
            'email' => $this->email,
            'status' => 1,
            'profile' =>  $name
        ]);
        $this->ref();
        $this->message = "Supplier Added Successfully";
        $this->dispatchBrowserEvent('add_show');
        $this->dispatchBrowserEvent('add_swal');
    }
    public function update()
    {
        $this->validate([
            'profile' => 'image|max:10000|nullable',
        ]);
        
            $date = date('YmdHis');
        if ($this->profile != null) {
            if (file_exists(public_path() . '/' . $this->supplier->profile)) {
                File::delete(public_path() . '/' . $this->supplier->profile);
            }
            $this->profile->storeAs('supplier', $date . '.png', 'profile');
            $this->supplier->profile = "uploads/supplier/" . $date . ".png";
        }
        
   
        $this->supplier->name = $this->name;
        $this->supplier->address = $this->address;
        $this->supplier->contact_number = $this->contact_number;
        $this->supplier->email = $this->email;

        $this->supplier->save();
        $this->ref();
        $this->message = "Supplier Updated Successfully";
        $this->dispatchBrowserEvent('edit_show');
        $this->dispatchBrowserEvent('edit_swal');
    }
    public function delete()
    {
        foreach ($this->supplier->tool_suppliers as $s) {
            $s->delete();
        }
        $this->supplier->status = 0;
        $this->supplier->save();
        $this->ref();
        $this->message = "Supplier Removed Successfully";
        $this->dispatchBrowserEvent('delete_show');
        $this->dispatchBrowserEvent('remove_swal');
    }
    public function contact()
    {
        supplier_contact::create([
            'supplier_id' => $this->supplier->id,
            'contact' => $this->contact,
            'type' => $this->type,
        ]);
        $this->ref();
        $this->message = "Contact for Supplier Successfully Created";
        $this->dispatchBrowserEvent('contact_show');
        $this->dispatchBrowserEvent('contact_swal');
    }
    public function delete_contact($id)
    {
        $contact = supplier_contact::find($id);
        $contact->delete();
        $this->ref();
        $this->message = "Contact Removed Successfully";
        $this->dispatchBrowserEvent('supplier_show');
        $this->dispatchBrowserEvent('contact_remove');
    }

    public function show_image($path)
    {
        $image = supplier::find($path);
        $this->path = $image->profile;
        $this->dispatchBrowserEvent('show_image');
    }
}
