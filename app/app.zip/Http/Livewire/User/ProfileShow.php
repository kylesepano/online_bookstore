<?php

namespace App\Http\Livewire\User;

use App\Models\login_details;
use App\Models\user;
use Illuminate\Support\Facades\Hash;
use Livewire\Component;
use Livewire\WithFileUploads;

class ProfileShow extends Component
{
    use WithFileUploads;
    public $message;
    public $password_error;
    public $photo;
    public $middlename;
    public $firstname;
    public $lastname;
    public $email;
    public $contact_number;
    public $address;
    public $oldpassword;
    public $password;
    public $password_confirmation;
    public function mount()
    {
        $this->ref();
    }
    public function render()
    {
        return view('livewire.user.profile-show');
    }
    public function ref()
    {
        $this->middlename =  auth()->user()->mname;
        $this->firstname =  auth()->user()->fname;
        $this->lastname =  auth()->user()->lname;
        $this->email =  auth()->user()->email;
        $this->contact_number =  auth()->user()->contact_number;
        $this->address =  auth()->user()->address;
        $this->message = null;
        $this->password_error = null;
        $this->oldpassword = null;
        $this->password = null;
        $this->password_confirmation = null;
    }
    public function update()
    {
        $this->message = "";
        $this->validate([
            'firstname' => 'required',
            'lastname' => 'required',
            'email' => 'email|unique:users,email,' . auth()->user()->id,
            'contact_number' => 'string|min:11|max:15|nullable|unique:users,contact_number,' . auth()->user()->id,
        ]);
        $user = user::find(auth()->user()->id);
        $user->mname = $this->middlename;
        $user->fname = $this->firstname;
        $user->lname = $this->lastname;
        $user->email = $this->email;
        $user->contact_number = $this->contact_number;
        $user->address = $this->address;
        $user->save();
        $this->message = "Profile updated successfully";
        $this->dispatchBrowserEvent('update_swal');
    }
    public function save()
    {
        $this->message = "";
        $this->validate([
            'photo' => 'image|max:10000',
        ]);
        $this->photo->storeAs('profile', auth()->user()->username . '.png', 'profile');
        $this->photo = null;
        $user = user::find(auth()->user()->id);
        $user->profile = "uploads/profile/" . auth()->user()->username . ".png";
        $user->save();
        $this->message = "Profile picture updated succesfully";
        $this->dispatchBrowserEvent('profile_swal');
    }
    public function change()
    {
        $this->password_error = null;
        $this->message = "";
        $this->validate([
            'oldpassword' => 'required|',
            'password' => 'required|confirmed|min:6',
        ]);
        if (Hash::check($this->oldpassword, auth()->user()->password)) {
            $user = user::find(auth()->user()->id);
            $user->password = Hash::make($this->password);
            $user->save();
            $this->message = "Password changed successfully";
            $this->dispatchBrowserEvent('password_swal');
        } else {
            $this->password_error = "Old password does not match with current password";
            $this->dispatchBrowserEvent('error_swal');
        }
    }
}
