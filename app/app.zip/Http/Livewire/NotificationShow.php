<?php

namespace App\Http\Livewire;

use Livewire\Component;

class NotificationShow extends Component
{
    public $holder = 0;
    public function mount(){
        $this->holder = count(auth()->user()->notification_messages());
    }
    public function render()
    {
        if ($this->holder < count(auth()->user()->notification_messages())) {
            $this->dispatchBrowserEvent('qwe');
        }
        $this->holder = count(auth()->user()->notification_messages());
        return view('livewire.notification-show');
    }
}
