<?php

namespace App\Http\Livewire;

use App\Models\category;
use App\Models\employee_service;
use App\Models\employee_specialty;
use App\Models\engineer_specialty;
use App\Models\engineer_specialty_assign;
use App\Models\equipment;
use App\Models\equipment_type;
use App\Models\service;
use App\Models\services;
use App\Models\services_assign;
use App\Models\specialty;
use App\Models\tool;
use App\Models\type;
use Livewire\Component;

use function PHPSTORM_META\type;

class MenuShow extends Component
{
    public $message;
    public $selector = 0;

    //datas
    public $specialties = [];
    public $services = [];
    public $categories = [];
    public $types = [];

    //specialty
    public $specialty;
    public $specialty_name;
    public $specialty_code;
    public $specialty_description;

    //service
    public $service;
    public $service_name;
    public $service_code;
    public $service_description;

    //category
    public $category;
    public $category_name;
    public $category_description;

    //types
    public $type;
    public $categories_id = "";
    public $type_name;
    public $type_description;
    public function render()
    {
        $this->dispatchBrowserEvent('data_table');
        $this->specialties = specialty::where('status', '!=', 0)->get();
        $this->services = service::where('status', '!=', 0)->get();
        $this->categories = category::where('status', '!=', 0)->get();
        $this->types = type::where('status', '!=', 0)->get();
        return view('livewire.menu-show');
    }
    public function select($selector)
    {
        $this->selector = $selector;
    }
    public function ref()
    {
        $this->message = null;
        $this->specialty = null;
        $this->specialty_name = null;
        $this->specialty_code = null;
        $this->specialty_description = null;
        $this->service = null;
        $this->service_name = null;
        $this->service_code = null;
        $this->service_description = null;
        $this->category = null;
        $this->category_name = null;
        $this->category_description = null;
        $this->type = null;
        $this->categories_id = "";
        $this->type_name = null;
        $this->type_description = null;
    }
    public function specialties_add()
    {
        $this->ref();
        $this->dispatchBrowserEvent('specialties_add');
    }
    public function specialties_show($id)
    {
        $this->ref();
        $this->specialty = specialty::find($id);
        $this->dispatchBrowserEvent('specialties_show');
    }
    public function specialties_edit($id)
    {
        $this->ref();
        $this->specialty = specialty::find($id);
        $this->specialty_name =  $this->specialty->specialty;
        $this->specialty_code = $this->specialty->specialty_code;
        $this->specialty_description = $this->specialty->description;
        $this->dispatchBrowserEvent('specialties_edit');
    }
    public function specialties_remove($id)
    {
        $this->ref();
        $this->specialty = specialty::find($id);
        $this->dispatchBrowserEvent('specialties_remove');
    }
    public function spec_add()
    {
        $this->validate([
            'specialty_name' => 'required',
            'specialty_code' => 'required|unique:specialties,specialty_code',
            'specialty_description' => 'required',
        ]);
        specialty::create([
            'specialty' => $this->specialty_name,
            'specialty_code' => $this->specialty_code,
            'description' => $this->specialty_description,
            'status' => 1,
        ]);
        $this->ref();
        $this->message = "Expertise Successfully Added";
        $this->dispatchBrowserEvent('specialties_add');
        $this->dispatchBrowserEvent('expertise_swal_add');
    }
    public function spec_edit()
    {
        $this->validate([
            'specialty_name' => 'required',
            'specialty_code' => 'required|unique:specialties,specialty_code,' . $this->specialty->id,
            'specialty_description' => 'required',
        ]);
        $this->specialty->specialty = $this->specialty_name;
        $this->specialty->specialty_code = $this->specialty_code;
        $this->specialty->description = $this->specialty_description;
        $this->specialty->save();
        $this->ref();
        $this->message = "Expertise Successfully Updated";
        $this->dispatchBrowserEvent('specialties_edit');
        $this->dispatchBrowserEvent('expertise_swal_edit');
    }
    public function spec_remove()
    {
        $engineer_specs = employee_specialty::where('specialty_id', $this->specialty->id)->get();
        foreach ($engineer_specs as $s) {
            $s->delete();
        }
        $this->specialty->status = 0;
        $this->specialty->save();
        $this->ref();
        $this->message = "Specialty Successfully Removed";
        $this->dispatchBrowserEvent('specialties_remove');
        $this->dispatchBrowserEvent('expertise_swal_remove');
    }
    public function services_add()
    {
        $this->ref();
        $this->dispatchBrowserEvent('services_add');
    }
    public function services_show($id)
    {
        $this->ref();
        $this->service = service::find($id);
        $this->dispatchBrowserEvent('services_show');
    }
    public function services_edit($id)
    {
        $this->ref();
        $this->service = service::find($id);
        $this->service_name =  $this->service->service;
        $this->service_code = $this->service->service_code;
        $this->service_description = $this->service->description;
        $this->dispatchBrowserEvent('services_edit');
    }
    public function services_remove($id)
    {
        $this->ref();
        $this->service = service::find($id);
        $this->dispatchBrowserEvent('services_remove');
    }
    public function ser_add()
    {
        $this->validate([
            'service_name' => 'required',
            'service_code' => 'required|unique:services,service_code',
            'service_description' => 'required',
        ]);
        service::create([
            'service' => $this->service_name,
            'service_code' => $this->service_code,
            'description' => $this->service_description,
            'status' => 1,
        ]);
        $this->ref();
        $this->message = "Service Successfully Added";
        $this->dispatchBrowserEvent('services_add');
        $this->dispatchBrowserEvent('service_swal_add');
    }
    public function ser_edit()
    {
        $this->validate([
            'service_name' => 'required',
            'service_code' => 'required|unique:services,service_code,' . $this->service->id,
            'service_description' => 'required',
        ]);
        $this->service->service = $this->service_name;
        $this->service->service_code = $this->service_code;
        $this->service->description = $this->service_description;
        $this->service->save();
        $this->ref();
        $this->message = "Service Successfully Updated";
        $this->dispatchBrowserEvent('services_edit');
        $this->dispatchBrowserEvent('service_swal_edit');
    }
    public function ser_remove()
    {
        $services = employee_service::where('service_id', $this->service->id)->get();
        foreach ($services as $s) {
            $s->delete();
        }
        $this->service->status = 0;
        $this->service->save();
        $this->ref();
        $this->message = "Services Successfully Removed";
        $this->dispatchBrowserEvent('services_remove');
        $this->dispatchBrowserEvent('service_swal_remove');
    }

    public function category_add()
    {
        $this->ref();
        $this->dispatchBrowserEvent('category_add');
    }
    public function category_show($id)
    {
        $this->ref();
        $this->category = category::find($id);
        $this->dispatchBrowserEvent('category_show');
    }
    public function category_edit($id)
    {
        $this->ref();
        $this->category = category::find($id);
        $this->category_name =  $this->category->category;
        $this->category_description = $this->category->description;
        $this->dispatchBrowserEvent('category_edit');
    }
    public function category_remove($id)
    {
        $this->ref();
        $this->category = category::find($id);
        $this->dispatchBrowserEvent('category_remove');
    }
    public function cat_add()
    {
        $this->validate([
            'category_name' => 'required|unique:categories,category',
            'category_description' => 'required',
        ]);
        category::create([
            'category' => $this->category_name,
            'description' => $this->category_description,
            'status' => 1,
        ]);
        $this->ref();
        $this->message = "Category Successfully Added";
        $this->dispatchBrowserEvent('category_add');
        $this->dispatchBrowserEvent('category_swal_add');
    }
    public function cat_edit()
    {
        $this->validate([
            'category_name' => 'required|unique:categories,category,' . $this->category->id,
            'category_description' => 'required',
        ]);
        $this->category->category = $this->category_name;
        $this->category->description = $this->category_description;
        $this->category->save();
        $this->ref();
        $this->message = "Category Successfully Updated";
        $this->dispatchBrowserEvent('category_edit');
        $this->dispatchBrowserEvent('category_swal_edit');
    }
    public function cat_remove()
    {
        $types = type::where('category_id', $this->category->id)->get();
        foreach ($types as $s) {
            foreach ($s->tools as $e) {
                $e->status = 0;
                $e->save();
            }
            $s->status = 0;
            $s->save();
        }
        $this->category->status = 0;
        $this->category->save();
        $this->ref();
        $this->message = "Category Successfully Removed";
        $this->dispatchBrowserEvent('category_remove');
        $this->dispatchBrowserEvent('category_swal_remove');
    }

    public function types_add()
    {
        $this->ref();
        $this->dispatchBrowserEvent('types_add');
    }
    public function types_show($id)
    {
        $this->ref();
        $this->type = type::find($id);
        $this->dispatchBrowserEvent('types_show');
    }
    public function types_edit($id)
    {
        $this->ref();
        $this->type = type::find($id);
        $this->categories_id =  $this->type->category_id;
        $this->type_name = $this->type->type;
        $this->type_description = $this->type->description;
        $this->dispatchBrowserEvent('types_edit');
    }
    public function types_remove($id)
    {
        $this->ref();
        $this->type = type::find($id);
        $this->dispatchBrowserEvent('types_remove');
    }
    public function typ_add()
    {
        $this->validate([
            'categories_id' => 'required',
            'type_name' => 'required|unique:types,type',
            'type_description' => 'required',
        ]);
        type::create([
            'category_id' => $this->categories_id,
            'type' => $this->type_name,
            'description' => $this->type_description,
            'status' => 1,
        ]);
        $this->ref();
        $this->message = "Equipment Type Successfully Added";
        $this->dispatchBrowserEvent('types_add');
        $this->dispatchBrowserEvent('type_swal_add');
    }
    public function typ_edit()
    {
        $this->validate([
            'categories_id' => 'required',
            'type_name' => 'required|unique:types,type,' . $this->type->id,
            'type_description' => 'required',
        ]);
        $this->type->category_id = $this->categories_id;
        $this->type->type = $this->type_name;
        $this->type->description = $this->type_description;
        $this->type->save();
        $this->ref();
        $this->message = "Equipment Type Successfully Updated";
        $this->dispatchBrowserEvent('types_edit');
        $this->dispatchBrowserEvent('type_swal_edit');
    }
    public function typ_remove()
    {
        $tools = tool::where('type_id', $this->type->id)->get();
        foreach ($tools as $t) {
            $t->status = 0;
            $t->save();
        }
        $this->type->status = 0;
        $this->type->save();
        $this->ref();
        $this->message = "Equipment Type Successfully Removed";
        $this->dispatchBrowserEvent('types_remove');
        $this->dispatchBrowserEvent('type_swal_remove');
    }
}
