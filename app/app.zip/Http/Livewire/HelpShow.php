<?php

namespace App\Http\Livewire;

use App\Models\inquiry;
use App\Models\inquiry_messages;
use Livewire\Component;

class HelpShow extends Component
{
    public $chat;
    public $inquiry;
    public $inquiries = [];
    public function mount($id)
    {
        if ($id != 0) {
            $this->inquiry = inquiry::find($id);
        }
    }
    public function render()
    {
        if (auth()->check()) {
            $this->inquiries = inquiry::where('staff_id', null)->orWhere('staff_id', auth()->user()->id)->orderBy('status', 'asc')->get();

            if (auth()->user()->user_type == 4) {
                if (auth()->user()->inquiry_user() != null) {
                    $latest = inquiry_messages::where('inquiry_id', auth()->user()->inquiry_user()->id)->latest()->first();
                    $inquiry = inquiry::find(auth()->user()->inquiry_user()->id);
                    $inquiry->user_message_id = $latest->id;
                    $inquiry->save();
                }
            } elseif (auth()->user()->user_type == 2) {
                if ($this->inquiry != null) {
                    $latest = inquiry_messages::where('inquiry_id', $this->inquiry->id)->latest()->first();
                    $this->inquiry->staff_message_id = $latest->id;
                    $this->inquiry->save();
                }
            }
        }
        return view('livewire.help-show');
    }
    public function send()
    {
        if ($this->chat != null) {
            if (auth()->user()->user_type == 4) {
                if (auth()->user()->inquiry_user() != null) {
                    inquiry_messages::create([
                        'inquiry_id' => auth()->user()->inquiry_user()->id,
                        'user_id' => auth()->user()->id,
                        'message' => $this->chat
                    ]);
                } else {
                    inquiry::create([
                        'user_id' => auth()->user()->id,
                        'status' => 1,
                    ]);
                    $inquiry = inquiry::latest()->first();
                    inquiry_messages::create([
                        'inquiry_id' => auth()->user()->inquiry_user()->id,
                        'user_id' => auth()->user()->id,
                        'message' => $this->chat
                    ]);
                }
                $this->chat = null;
            } else {
                if ($this->inquiry->staff_id == null) {
                    $this->inquiry->staff_id = auth()->user()->id;
                    $this->inquiry->save();
                }
                inquiry_messages::create([
                    'inquiry_id' => $this->inquiry->id,
                    'user_id' => auth()->user()->id,
                    'message' => $this->chat
                ]);
                $this->chat = null;
            }
        }
    }
    public function done()
    {

        if (auth()->user()->user_type == 4) {
            if (auth()->user()->inquiry_user() != null) {
                $inquiry = inquiry::find(auth()->user()->inquiry_user()->id);
                $inquiry->status = 2;
                $inquiry->save();
            }
        } else {
            if ($this->inquiry->staff_id == null) {
                $this->inquiry->staff_id = auth()->user()->id;
                $this->inquiry->save();
            }
            $inquiry = inquiry::find($this->inquiry->id);
            $inquiry->status = 2;
            $inquiry->save();
        }
    }
    public function check($id)
    {
        $this->inquiry = inquiry::find($id);
    }
    public function back()
    {
        $this->inquiry = null;
    }
}
