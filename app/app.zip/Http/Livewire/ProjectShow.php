<?php

namespace App\Http\Livewire;

use App\Models\proj;

use App\Models\project_image;
use Livewire\Component;
use Livewire\WithFileUploads;

class ProjectShow extends Component
{
    use WithFileUploads;
    public $name;
    public $location;

    public $path;
    public $images;
    public $projects = [];
    public $project;
    public function render()
    {
        $this->projects = proj::all();
        return view('livewire.project-show');
    }
    public function ref()
    {
        $this->name = null;
        $this->location = null;
        $this->images = null;
    }
    public function add_show()
    {
        $this->ref();
        $this->dispatchBrowserEvent('add_show');
    }
    public function edit_show($id)
    {
        $this->project = proj::find($id);
        $this->name = $this->project->name;
        $this->location = $this->project->location;
        $this->dispatchBrowserEvent('edit_show');
    }
    public function remove_show($id)
    {
        $this->project = proj::find($id);
        $this->dispatchBrowserEvent('remove_show');
    }
    public function create()
    {
        $this->validate([
            'name' => 'required|unique:projs',
        ]);
        proj::create([
            'name' => $this->name,
            'location' => $this->location,
        ]);
        $project = proj::latest()->first();
        foreach ($this->images as $im) {
            $name = "uploads/project/" . $project->name . '/' . $im->getClientOriginalName();
            $im->storeAs('project/' . $project->name, $im->getClientOriginalName(), 'profile');
            project_image::create([
                'project_id' => $project->id,
                'image' => $name
            ]);
        }
        $this->dispatchBrowserEvent('add_show');
        $this->dispatchBrowserEvent('add_swal');
    }
    public function update()
    {
        $this->validate([
            'name' => 'required|unique:projs,name,' . $this->project->id,
        ]);
        $this->project->name = $this->name;
        $this->project->location = $this->location;
        $this->project->save();

        if ($this->images != null) {
            foreach ($this->images as $im) {
                $name = "uploads/project/" . $this->project->name . '/' . $im->getClientOriginalName();
                $im->storeAs('project/' . $this->project->name, $im->getClientOriginalName(), 'profile');
                project_image::create([
                    'project_id' => $this->project->id,
                    'image' => $name
                ]);
            }
        }

        $this->dispatchBrowserEvent('edit_show');
        $this->dispatchBrowserEvent('edit_swal');
    }
    public function delete()
    {
        $images = project_image::where('project_id', $this->project->id)->get();
        foreach ($images as $im) {
            $im->delete();
        }
        $this->project->delete();
        $this->ref();
        $this->dispatchBrowserEvent('remove_show');
        $this->dispatchBrowserEvent('remove_swal');
    }
    public function remove_image($id)
    {
        $images = project_image::find($id);
        $images->delete();
        $this->dispatchBrowserEvent('edit_show');
        $this->dispatchBrowserEvent('image_swal');
    }

    public function show_image($path)
    {
        $image = project_image::find($path);
        $this->path = $image->image;
        $this->dispatchBrowserEvent('show_image');
    }
}
