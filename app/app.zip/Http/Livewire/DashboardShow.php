<?php

namespace App\Http\Livewire;

use App\Models\appointment;
use App\Models\tool;
use App\Models\user;
use Illuminate\Support\Facades\App;
use Livewire\Component;

class DashboardShow extends Component
{
    public $users = 0;
    public $employees = 0;
    public $appointments = 0;
    public $equipments = 0;
    public $from;
    public $to;
    public function mount()
    {
        $this->ref();
        $this->users = user::where('user_type', 4)->where('status', '!=', 0)->count();
        $this->employees = user::where(function ($e) {
            $e->where('user_type', 3);
        })->where('status', '!=', 0)->count();
        $this->appointments = appointment::where('status', '!=', 0)->count();
        $this->equipments = tool::where('status', '!=', 0)->count();
    }
    public function render()
    {
        return view('livewire.dashboard-show');
    }
    public function ref()
    {
        $this->from = date('Y-m-d');
        $this->to = date('Y-m-d');
    }
    public function user_show()
    {
        $this->ref();
        $this->dispatchBrowserEvent('user_show');
    }
    public function employee_show()
    {
        $this->ref();
        $this->dispatchBrowserEvent('employee_show');
    }
    public function appointment_show()
    {
        $this->ref();
        $this->dispatchBrowserEvent('appointment_show');
    }
    public function equipment_show()
    {
        $this->ref();
        $this->dispatchBrowserEvent('equipment_show');
    }
    public function user()
    {
        $name = "user-" . date('M d, Y') . '.pdf';

        return response()->streamDownload(function () {

            $users = user::where('user_type', 4)->where('status', '!=', 0)->get();

            $user = [];
            $contact_number = [];
            $email = [];
            $address = [];

            $x = 0;

            foreach ($users as $e) {
                $user[$x] = $e->fullname();
                $contact_number[$x] = $e->contact_number;
                $email[$x] = $e->email;
                $address[$x] = $e->address;
                $x += 1;
            }

            $data = [
                'user' => $user,
                'contact_number' => $contact_number,
                'email' => $email,
                'address' => $address,
            ];
            $pdf = App::make('dompdf.wrapper');
            $pdf->set_paper('letter', 'portrait');
            $pdf->loadView('print.users', $data);
            echo $pdf->stream();
        }, $name);
    }
    public function employee()
    {
        $name = "employees-" . date('M d, Y') . '.pdf';

        return response()->streamDownload(function () {

            $employees = user::where('user_type', 3)->where('status', '!=', 0)->get();

            $user = [];
            $contact_number = [];
            $email = [];
            $address = [];
            $services = [];
            $expertise = [];
            $x = 0;

            foreach ($employees as $e) {
                $user[$x] = $e->fullname();
                $contact_number[$x] = $e->contact_number;
                $email[$x] = $e->email;
                $address[$x] = $e->address;

                $y = 0;
                foreach ($e->specialties as $u) {
                    $expertise[$x][$y] = $u->specialty->specialty;
                    $y += 1;
                }
                $y = 0;
                foreach ($e->services as $u) {
                    $services[$x][$y] = $u->service->service;
                    $y += 1;
                }
                $x += 1;
            }

            $data = [
                'user' => $user,
                'contact_number' => $contact_number,
                'email' => $email,
                'address' => $address,
                'expertise' => $expertise,
                'services' => $services
            ];
            $pdf = App::make('dompdf.wrapper');
            $pdf->set_paper('letter', 'portrait');
            $pdf->loadView('print.employees', $data);
            echo $pdf->stream();
        }, $name);
    }
    public function appointment()
    {
        $name = "appiontments-" . date('M d, Y', strtotime($this->from)) . '-'  .  date('M d, Y', strtotime($this->to)) . '.pdf';

        return response()->streamDownload(function () {

            $appointments = appointment::where('date', '>=', $this->from)->where('date', '<=', $this->to)->orderBy('date')->get();

            $date = [];
            $user = [];
            $staff = [];
            $employees = [];
            $status = [];

            $x = 0;

            foreach ($appointments as $a) {
                $date[$x] = date('M d, Y', strtotime($a->date));
                $user[$x] = $a->user->fullname();
                $staff[$x] = $a->staff->fullname();
                $status[$x] = $a->stat();
                $y = 0;

                foreach ($a->appointment_users as $u) {

                    $employees[$x][$y] = $u->user->fullname();
                    $y += 1;
                }
                $x += 1;
            }

            $data = [
                'date' => $date,
                'user' => $user,
                'staff' => $staff,
                'status' => $status,
                'employees' => $employees
            ];
            $pdf = App::make('dompdf.wrapper');
            $pdf->set_paper('letter', 'portrait');
            $pdf->loadView('print.appointments', $data);
            echo $pdf->stream();
        }, $name);
    }
    public function equipment()
    {
        $name = "equipment-" . date('M d, Y') . '.pdf';

        return response()->streamDownload(function () {

            $equipments = tool::where('status', '!=', 0)->get();

            $name = [];
            $category = [];
            $type = [];
            $suppliers = [];
            $prices = [];

            $x = 0;

            foreach ($equipments as $e) {
                $name[$x] = $e->name;
                $category[$x] = $e->type->category->category;
                $type[$x] = $e->type->type;

                $y = 0;
                foreach ($e->tool_suppliers as $s) {
                    $suppliers[$x][$y] = $s->supplier->name;
                    $prices[$x][$y] = $s->price;
                    $y += 1;
                }
                $x += 1;
            }

            $data = [
                'name' => $name,
                'category' => $category,
                'type' => $type,
                'suppliers' => $suppliers,
                'prices' => $prices,
            ];
            $pdf = App::make('dompdf.wrapper');
            $pdf->set_paper('letter', 'portrait');
            $pdf->loadView('print.equipments', $data);
            echo $pdf->stream();
        }, $name);
    }
}
