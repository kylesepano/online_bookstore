<?php

namespace App\Http\Livewire;

use App\Models\category;
use App\Models\equipment;
use App\Models\equipment_type;
use App\Models\equipments_supplier;
use App\Models\services;
use App\Models\supplier;
use App\Models\tool;
use App\Models\tool_supplier;
use App\Models\type;
use Livewire\Component;
use Livewire\WithFileUploads;
use Livewire\WithPagination;
use function PHPSTORM_META\type;
use Illuminate\Support\Facades\File;
class EquipmentsShow extends Component
{
    use WithPagination;
    use WithFileUploads;
    protected $paginationTheme = 'bootstrap';
    public $categories;
    public $types;
    public $selected_types = [];
    public $selected_categories = [];
    public $search = "";
    public $sort = 1;
    public $message;
    public $e_selected_category = "";
    public $e_types = [];
    public $equipment_types_id = "";
    public $name;
    public $equipment_code;
    public $price_start = 0;
    public $description;
    public $price_end = 0;
    public $image;
    public $suppliers = [];
    public $selected_suppliers;
    public $prices = [];
    public $equipment;
    public $price;
    public $price_amount = 0;


    public $path;
    public function render()
    {
        $sort = "DESC";
        if ($this->sort == 2) {
            $sort = "ASC";
        }
        $checker_cat = false;
        foreach ($this->selected_categories as $s) {
            if ($s != false) {
                $checker_cat = true;
            }
        }
        $this->categories = category::where('status', '!=', 0)->get();
        if ($checker_cat) {
            $this->types = type::whereIn('category_id', $this->selected_categories)->where('status', '!=', 0)->get();
            $arr = type::whereIn('category_id', $this->selected_categories)->pluck('id')->toArray();
            foreach ($this->selected_types as $key => $s) {
                if (!in_array($key, $arr)) {
                    $this->selected_types[$key] = false;
                }
            }
        } else {
            $this->types = type::where('status', '!=', 0)->get();
        }
        $checker_t = false;
        foreach ($this->selected_types as $s) {
            if ($s != false) {
                $checker_t = true;
            }
        }
        if ($checker_cat) {
            if ($checker_t) {
                $equipments = tool::whereIn('type_id', $this->selected_types)->where('status', '!=', 0)->orderBy('created_at', $sort)->where(function ($e) {
                    $e->where('name', 'like', '%' . $this->search . '%')->orWhere('equipment_code', 'like', '%' . $this->search . '%');
                })->where('status', '!=', 0)->paginate(9);
            } else {
                $equipments = tool::whereIn('type_id', type::whereIn('category_id', $this->selected_categories)->pluck('id')->toArray())->where(function ($e) {
                    $e->where('name', 'like', '%' . $this->search . '%')->orWhere('equipment_code', 'like', '%' . $this->search . '%');
                })->where('status', '!=', 0)->orderBy('created_at', $sort)->where('status', '!=', 0)->paginate(9);
            }
        } else {
            if ($checker_t) {
                $equipments = tool::whereIn('type_id', $this->selected_types)->where('status', '!=', 0)->orderBy('created_at', $sort)->where(function ($e) {
                    $e->where('name', 'like', '%' . $this->search . '%')->orWhere('equipment_code', 'like', '%' . $this->search . '%');
                })->where('status', '!=', 0)->paginate(9);
            } else {
                $equipments = tool::where('status', '!=', 0)->orderBy('created_at', $sort)->where(function ($e) {
                    $e->where('name', 'like', '%' . $this->search . '%')->orWhere('equipment_code', 'like', '%' . $this->search . '%');
                })->where('status', '!=', 0)->paginate(9);
            }
        }
        $this->e_types = type::where('category_id', $this->e_selected_category)->where('status', '!=', 0)->get();
        $this->dispatchBrowserEvent('data_table');
        return view('livewire.equipments-show', ['equipments' => $equipments]);
    }
    public function ref()
    {
        $this->sort = 1;
        $this->e_selected_category = "";
        $this->e_types = [];
        $this->equipment_types_id = "";
        $this->name = null;
        $this->equipment_code = null;
        $this->price_start = 0;
        $this->description = null;
        $this->price_end = 0;
        $this->image = null;
        $this->selected_suppliers = [];
        $this->prices = [];
        $this->price = null;
        $this->price_amount = 0;
    }
    public function add_show()
    {
        $this->ref();
        $this->dispatchBrowserEvent('add_show');
    }
    public function edit_show($id)
    {
        $this->ref();
        $this->equipment = tool::find($id);
        $this->name = $this->equipment->name;
        $this->e_selected_category = $this->equipment->type->category->id;
        $this->equipment_types_id = $this->equipment->type_id;
        $this->equipment_code = $this->equipment->equipment_code;
        $this->price_start = $this->equipment->price_start;
        $this->description = $this->equipment->description;
        $this->price_end = $this->equipment->price_end;
        $this->dispatchBrowserEvent('edit_show');
    }
    public function equipment_show($id)
    {
        $this->equipment = tool::find($id);
        $this->ref();
        $this->dispatchBrowserEvent('equipment_show');
    }
    public function delete_show($id)
    {
        $this->equipment = tool::find($id);
        $this->ref();
        $this->dispatchBrowserEvent('delete_show');
    }
    public function supplier_show($id)
    {
        $this->equipment = tool::find($id);
        $this->suppliers = supplier::where('status', '!=', 0)->whereNotIn('id', tool_supplier::where('tool_id', $this->equipment->id)->pluck('supplier_id')->toArray())->get();
        $this->ref();
        $this->dispatchBrowserEvent('supplier_show');
    }
    public function create()
    {
        $this->validate([
            'equipment_code' => 'max:255|unique:tools',
            'image' => 'image|max:10000|nullable',
        ]);

         $name = null;
        $date = date('YmdHis');
        if ($this->image != null) {
            $name = "uploads/equipment/" . $date . ".png";
            $this->image->storeAs('equipment', $date . '.png', 'profile');
        }
        tool::create([
            'name' => $this->name,
            'description' => $this->description,
            'price_start' => $this->price_start,
            'price_end' => $this->price_end,
            'equipment_code' => $this->equipment_code,
            'image' => $name,
            'type_id' => $this->equipment_types_id,
            'status' => 1,
        ]);
        $this->ref();
        $this->message = "Equipment Added Successfully";
        $this->dispatchBrowserEvent('add_show');
        $this->dispatchBrowserEvent('add_swal');
    }
    public function show_image($path)
    {
        $image = tool::find($path);
        $this->path = $image->image;
        $this->dispatchBrowserEvent('show_image');
    }
    public function update()
    {
        $this->validate([
            'equipment_code' => 'max:255|unique:tools,equipment_code,' . $this->equipment->id,
            'image' => 'image|max:10000|nullable',
        ]);
  
         $date = date('YmdHis');
        if ($this->image != null) {
            if (file_exists(public_path() . '/' . $this->equipment->image)) {
                File::delete(public_path() . '/' . $this->equipment->image);
            }
            $this->image->storeAs('equipment', $date . '.png', 'profile');
            $this->equipment->image = "uploads/equipment/" . $date . ".png";
        }
        $this->equipment->name = $this->name;
        $this->equipment->description = $this->description;
        $this->equipment->price_start = $this->price_start;
        $this->equipment->price_end = $this->price_end;
        $this->equipment->type_id = $this->equipment_types_id;
        $this->equipment->equipment_code = $this->equipment_code;
        $this->equipment->save();
        $this->ref();
        $this->message = "Equipment Updated Successfully";
        $this->dispatchBrowserEvent('edit_show');
        $this->dispatchBrowserEvent('edit_swal');
    }
    public function delete()
    {
        $this->equipment->status = 0;
        $this->equipment->save();
        $this->ref();
        $this->message = "Equipment Removed Successfully";
        $this->dispatchBrowserEvent('delete_show');
        $this->dispatchBrowserEvent('remove_swal');
    }
    public function supplier()
    {
        foreach ($this->selected_suppliers as $s) {
            if ($s) {
                tool_supplier::create([
                    'tool_id' => $this->equipment->id,
                    'supplier_id' => $s,
                    'price' =>   $this->prices[$s]
                ]);
            }
        }
        $this->ref();
        $this->message = "Equipment Supplier Successfully Added";
        $this->dispatchBrowserEvent('supplier_show');
        $this->dispatchBrowserEvent('supplier_swal');
    }
    public function delete_supplier($id)
    {
        $supplier = tool_supplier::find($id);
        $supplier->delete();
        $this->ref();
        $this->message = "Equipment Supplier Removed Successfully";
        $this->dispatchBrowserEvent('equipment_show');
        $this->dispatchBrowserEvent('supplier_remove');
    }

    public function price_change($id)
    {
        $this->price = tool_supplier::find($id);
        $this->price_amount = $this->price->price;
    }
    public function price_update()
    {
        $this->price->price = $this->price_amount;
        $id = $this->price->tool_id;
        $this->price->save();
        $this->price = null;
        $this->equipment = tool::find($id);
        $this->price_amount = 0;
        $this->dispatchBrowserEvent('price_swal');
    }
}
