<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Inquires extends Component
{
    public $holder = 0;
    public function mount()
    {
        $this->holder = count(auth()->user()->notification_helps());
    }
    public function render()
    {
        if ($this->holder < count(auth()->user()->notification_helps())) {
            $this->dispatchBrowserEvent('zxc');
        }
        $this->holder = count(auth()->user()->notification_helps());
        return view('livewire.inquires');
    }
}
