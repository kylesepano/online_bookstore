<?php

namespace App\Http\Livewire;

use App\Models\user;
use Livewire\Component;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Livewire\WithFileUploads;
use Livewire\WithPagination;
use Illuminate\Support\Facades\File;

class StaffShow extends Component
{
    use WithPagination;
    use WithFileUploads;
    protected $paginationTheme = 'bootstrap';
    public $search = "";
    public $message;
    public $status = 1;
    public $sort = 1;
    public $firstname;
    public $lastname;
    public $mname;
    public $email;
    public $address;
    public $contact_number;
    public $profile;
    public $username;

    public $staff;

    public $path;
    public function render()
    {
        $this->dispatchBrowserEvent('data_table');
        $sort = "DESC";
        if ($this->sort == 2) {
            $sort = "ASC";
        }

        $staffs = user::where('user_type', 2)->where('status', $this->status)->where(function ($e) {
            $e->where('fname', 'like', '%' . $this->search . '%')->orWhere('address', 'mname', '%' . $this->search . '%')->orWhere('lname', 'like', '%' . $this->search . '%');
        })->orderBy('created_at', $sort)->paginate(12);
        return view('livewire.staff-show', ['staffs' => $staffs]);
    }
    public function ref()
    {
        $this->sort = 1;
        $this->firstname = null;
        $this->lastname = null;
        $this->mname = null;
        $this->email = null;
        $this->address = null;
        $this->contact_number = null;
        $this->username = null;
    }
    public function add_show()
    {
        $this->ref();
        $this->dispatchBrowserEvent('add_show');
    }
    public function show_image($path)
    {
        $image = user::find($path);
        $this->path = $image->profile;
        $this->dispatchBrowserEvent('show_image');
    }
    public function edit_show($id)
    {
        $this->ref();
        $this->staff = user::find($id);
        $this->firstname = $this->staff->fname;
        $this->lastname = $this->staff->lname;
        $this->mname = $this->staff->mname;
        $this->email = $this->staff->email;
        $this->address = $this->staff->address;
        $this->contact_number = $this->staff->contact_number;
        $this->username = $this->staff->username;

        $this->dispatchBrowserEvent('edit_show');
    }
    public function delete_show($id)
    {
        $this->staff = user::find($id);
        $this->ref();
        $this->dispatchBrowserEvent('delete_show');
    }
    public function activate_show($id)
    {
        $this->staff = user::find($id);
        $this->ref();
        $this->dispatchBrowserEvent('activate_show');
    }
    public function staff_show($id)
    {
        $this->staff = user::find($id);
        $this->ref();
        $this->dispatchBrowserEvent('staff_show');
    }
    public function create()
    {
        $this->validate([
            'firstname' => 'required',
            'lastname' => 'required',
            'username' => 'required|unique:users',
            'contact_number' => 'min:11|max:15|nullable|unique:users',
            'email' => 'email|nullable|unique:users',
            'profile' => 'image|max:10000|nullable',
        ]);
  
        $name = null;
        $date = date('YmdHis');
        if ($this->profile != null) {
            $name = "uploads/staff/" . $date . ".png";
            $this->profile->storeAs('staff', $date . '.png', 'profile');
        }
        $password = Str::lower(str_replace(" ", "", ($this->firstname) . ($this->lastname)));
        user::create([
            'username' => $this->username,
            'password' => Hash::make($password),
            'user_type' => 2,
            'status' => 1,
            'mname' => $this->mname,
            'fname' => $this->firstname,
            'lname' => $this->lastname,
            'address' => $this->address,
            'contact_number' => $this->contact_number,
            'email' => $this->email,
            'profile' => $name,
        ]);

        $this->message = "Staff Successfully Added";
        $this->dispatchBrowserEvent('add_show');
        $this->dispatchBrowserEvent('add_swal');
    }
    public function update()
    {
        $this->validate([
            'firstname' => 'required',
            'lastname' => 'required',
            'username' => 'required|unique:users,username,' . $this->staff->id,
            'contact_number' => 'min:11|max:15|nullable|unique:users,contact_number,' . $this->staff->id,
            'email' => 'email|nullable|unique:users,email,' . $this->staff->id,
            'profile' => 'image|max:10000|nullable',
        ]);
        
            $date = date('YmdHis');
        if ($this->profile != null) {
            if (file_exists(public_path() . '/' . $this->staff->profile)) {
                File::delete(public_path() . '/' . $this->staff->profile);
            }
            $this->profile->storeAs('staff', $date . '.png', 'profile');
            $this->staff->profile = "uploads/staff/" . $date . ".png";
        }
        
  
        $this->staff->fname = $this->firstname;
        $this->staff->lname = $this->lastname;
        $this->staff->mname = $this->mname;
        $this->staff->username = $this->username;
        $this->staff->contact_number = $this->contact_number;
        $this->staff->email = $this->email;
        $this->staff->address = $this->address;
        $this->staff->save();
        $this->ref();
        $this->message = "Staff Updated Successfully";
        $this->dispatchBrowserEvent('edit_show');
        $this->dispatchBrowserEvent('edit_swal');
    }
    public function delete()
    {
        $this->ref();
        $this->staff->status = 0;
        $this->staff->save();
        $this->message = "Staff Successfully Removed";
        $this->dispatchBrowserEvent('delete_show');
        $this->dispatchBrowserEvent('delete_swal');
    }
    public function activate()
    {
        $this->ref();
        $this->staff->status = 1;
        $this->staff->save();
        $this->message = "Staff Successfully Added";
        $this->dispatchBrowserEvent('activate_show');
        $this->dispatchBrowserEvent('activate_swal');
    }
}
