<?php

namespace App\Http\Livewire;

use App\Models\user;
use Livewire\Component;
use Illuminate\Support\Str;
use Livewire\WithPagination;

class UserShow extends Component
{
    use WithPagination;
    protected $paginationTheme = 'bootstrap';
    public $message;
    public $search = "";
    public $sort = 1;
    public $status = 1;
    public $user;
    public function render()
    {
        $this->dispatchBrowserEvent('data_table');
        $sort = "DESC";
        if ($this->sort == 2) {
            $sort = "ASC";
        }
        $users = user::where('user_type', 4)->where('status', $this->status)->where(function ($e) {
            $e->where('fname', 'like', '%' . $this->search . '%')->orWhere('address', 'mname', '%' . $this->search . '%')->orWhere('lname', 'like', '%' . $this->search . '%');
        })->orderBy('created_at', $sort)->paginate(12);
        return view('livewire.user-show', ['users' => $users]);
    }
    public function ref()
    {
        $this->message = null;
    }
    public function delete_show($id)
    {
        $this->user = user::find($id);
        $this->ref();
        $this->dispatchBrowserEvent('delete_show');
    }
    public function activate_show($id)
    {
        $this->user = user::find($id);
        $this->ref();
        $this->dispatchBrowserEvent('activate_show');
    }
    public function user_show($id)
    {
        $this->user = user::find($id);
        $this->ref();
        $this->dispatchBrowserEvent('user_show');
    }
    public function delete()
    {
        $this->ref();
        $this->user->status = 0;
        $this->user->save();
        $this->message = "User Successfully Removed";
        $this->dispatchBrowserEvent('delete_show');
        $this->dispatchBrowserEvent('remove_swal');
    }
    public function activate()
    {
        $this->ref();
        $this->user->status = 1;
        $this->user->save();
        $this->message = "User Successfully Added";
        $this->dispatchBrowserEvent('activate_show');
        $this->dispatchBrowserEvent('add_swal');
    }
}
