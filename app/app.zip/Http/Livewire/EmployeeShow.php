<?php

namespace App\Http\Livewire;

use App\Models\appointment;
use App\Models\appointment_user;
use App\Models\employee_service;
use App\Models\employee_specialty;
use App\Models\service;
use App\Models\specialty;
use App\Models\user;
use Illuminate\Support\Facades\Hash;
use Livewire\Component;
use Illuminate\Support\Str;
use Livewire\WithFileUploads;
use Livewire\WithPagination;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\File;

class EmployeeShow extends Component
{
    use WithPagination;
    use WithFileUploads;
    protected $paginationTheme = 'bootstrap';
    public $search = "";
    public $message;
    public $status = 1;
    public $sort = 1;
    public $firstname;
    public $lastname;
    public $mname;
    public $email;
    public $address;
    public $contact_number;
    public $profile;
    public $username;
    public $employee;
    public $services = [];
    public $specialties = [];
    public $selected_services = [];
    public $selected_specialties = [];
    public $a_specialties_selected = [];
    public $a_services_selected = [];
    public $a_specialties = [];
    public $a_services = [];

    //user
    public $date;
    public $selected_engineer = [];
    public $set_appointment = false;
    public $description;

    public $path;
    public function mount()
    {
        $this->date = date('Y-m-d');
    }
    public function render()
    {

        $this->dispatchBrowserEvent('data_table');
        $sort = "DESC";
        if ($this->sort == 2) {
            $sort = "ASC";
        }

        $ser = false;
        foreach ($this->selected_services as $s) {
            if ($s != false) {
                $ser = true;
            }
        }
        $spec = false;
        foreach ($this->selected_specialties as $s) {
            if ($s != false) {
                $spec = true;
            }
        }

        if ($spec || $ser) {

            if (auth()->user()->user_type != 4) {
                $employees = user::where('user_type', 3)->where('status', $this->status)->where(function ($e) {
                    $e->where('fname', 'like', '%' . $this->search . '%')->orWhere('address', 'mname', '%' . $this->search . '%')->orWhere('lname', 'like', '%' . $this->search . '%');
                })->where(function ($w) {
                    $w->whereIn('id', employee_service::whereIn('service_id', $this->selected_services)->pluck('user_id')->toArray())->orWhereIn('id', employee_specialty::whereIn('specialty_id', $this->selected_specialties)->pluck('user_id')->toArray());
                })->orderBy('created_at', $sort)->paginate(9);
            } else {
                $employees = user::where('user_type', 3)->where('status', $this->status)->where(function ($e) {
                    $e->where('fname', 'like', '%' . $this->search . '%')->orWhere('address', 'mname', '%' . $this->search . '%')->orWhere('lname', 'like', '%' . $this->search . '%');
                })->where(function ($w) {
                    $w->whereIn('id', employee_service::whereIn('service_id', $this->selected_services)->pluck('user_id')->toArray())->orWhereIn('id', employee_specialty::whereIn('specialty_id', $this->selected_specialties)->pluck('user_id')->toArray());
                })->whereNotIn('id', appointment_user::whereIn('appointment_id', appointment::where('date', $this->date)->where('status', 2)->pluck('id')->toArray())->pluck('user_id')->toArray())->orderBy('created_at', $sort)->paginate(9);
            }
        } else {
            if (auth()->user()->user_type != 4) {
                $employees = user::where('user_type', 3)->where('status', $this->status)->where(function ($e) {
                    $e->where('fname', 'like', '%' . $this->search . '%')->orWhere('address', 'mname', '%' . $this->search . '%')->orWhere('lname', 'like', '%' . $this->search . '%');
                })->orderBy('created_at', $sort)->paginate(9);
            } else {
                $employees = user::where('user_type', 3)->where('status', $this->status)->where(function ($e) {
                    $e->where('fname', 'like', '%' . $this->search . '%')->orWhere('address', 'mname', '%' . $this->search . '%')->orWhere('lname', 'like', '%' . $this->search . '%');
                })->whereNotIn('id', appointment_user::whereIn('appointment_id', appointment::where('date', $this->date)->where('status', 2)->pluck('id')->toArray())->pluck('user_id')->toArray())->orderBy('created_at', $sort)->paginate(9);
            }
        }
        $this->services = service::where('status', '!=', 0)->get();
        $this->specialties = specialty::where('status', '!=', 0)->get();
        $this->set_appointment = false;
        foreach ($this->selected_engineer as $e) {
            if ($e) {
                $this->set_appointment = true;
            }
        }
        return view('livewire.employee-show', ['employees' => $employees]);
    }
    public function ref()
    {
        $this->sort = 1;
        $this->firstname = null;
        $this->lastname = null;
        $this->mname = null;
        $this->email = null;
        $this->address = null;
        $this->contact_number = null;
        $this->username = null;
    }
    public function add_show()
    {
        $this->ref();
        $this->dispatchBrowserEvent('add_show');
    }
    public function edit_show($id)
    {
        $this->ref();
        $this->employee = user::find($id);
        $this->firstname = $this->employee->fname;
        $this->lastname = $this->employee->lname;
        $this->mname = $this->employee->mname;
        $this->email = $this->employee->email;
        $this->address = $this->employee->address;
        $this->contact_number = $this->employee->contact_number;
        $this->username = $this->employee->username;
        $this->a_services_selected = [];
        $this->description = null;
        $this->a_specialties_selected = [];
        $this->dispatchBrowserEvent('edit_show');
    }
    public function delete_show($id)
    {
        $this->employee = user::find($id);
        $this->ref();
        $this->dispatchBrowserEvent('delete_show');
    }
    public function activate_show($id)
    {
        $this->employee = user::find($id);
        $this->ref();
        $this->dispatchBrowserEvent('activate_show');
    }
    public function employee_show($id)
    {
        $this->employee = user::find($id);
        $this->ref();
        $this->dispatchBrowserEvent('employee_show');
    }
    public function services_show($id)
    {
        $this->employee = user::find($id);
        $this->ref();
        $this->a_services = service::where('status', '!=', 0)->whereNotIn('id', employee_service::where('user_id', $this->employee->id)->pluck('service_id')->toArray())->get();
        $this->dispatchBrowserEvent('services_show');
    }
    public function specialties_show($id)
    {
        $this->employee = user::find($id);
        $this->ref();
        $this->a_specialties = specialty::where('status', '!=', 0)->whereNotIn('id', employee_specialty::where('user_id', $this->employee->id)->pluck('specialty_id')->toArray())->get();
        $this->dispatchBrowserEvent('specialties_show');
    }
    public function create()
    {
        $this->validate([
            'firstname' => 'required',
            'lastname' => 'required',
            'username' => 'required|unique:users',
            'contact_number' => 'min:11|max:15|nullable|unique:users',
            'email' => 'email|nullable|unique:users',
            'profile' => 'image|max:10000|nullable',
        ]);
         $name = null;
        $date = date('YmdHis');
        if ($this->profile != null) {
              $name = "uploads/employee/" . $date . ".png";
            $this->profile->storeAs('employee', $date . '.png', 'profile');
        }
        $password = Str::lower(str_replace(" ", "", ($this->firstname) . ($this->lastname)));
        user::create([
            'username' => $this->username,
            'password' => Hash::make($password),
            'user_type' => 3,
            'status' => 1,
            'mname' => $this->mname,
            'fname' => $this->firstname,
            'lname' => $this->lastname,
            'address' => $this->address,
            'contact_number' => $this->contact_number,
            'email' => $this->email,
            'profile' => $name,
        ]);

        $this->message = "Employee Successfully Added";
        $this->dispatchBrowserEvent('add_show');
        $this->dispatchBrowserEvent('add_swal');
    }
    public function update()
    {
        $this->validate([
            'firstname' => 'required',
            'lastname' => 'required',
            'username' => 'required|unique:users,username,' . $this->employee->id,
            'contact_number' => 'min:11|max:15|nullable|unique:users,contact_number,' . $this->employee->id,
            'email' => 'email|nullable|unique:users,email,' . $this->employee->id,
            'profile' => 'image|max:10000|nullable',
        ]);
      $date = date('YmdHis');
        if ($this->profile != null) {
            if (file_exists(public_path() . '/' . $this->employee->profile)) {
                File::delete(public_path() . '/' . $this->employee->profile);
            }
            $this->profile->storeAs('employee', $date . '.png', 'profile');
            $this->employee->profile = "uploads/employee/" . $date . ".png";
        }
        $this->employee->fname = $this->firstname;
        $this->employee->lname = $this->lastname;
        $this->employee->mname = $this->mname;
        $this->employee->username = $this->username;
        $this->employee->contact_number = $this->contact_number;
        $this->employee->email = $this->email;
        $this->employee->address = $this->address;
        $this->employee->save();
       
        $this->ref();
        $this->message = "Employee Updated Successfully";
        $this->dispatchBrowserEvent('edit_show');
        $this->dispatchBrowserEvent('edit_swal');
    }
    public function delete()
    {
        $this->ref();
        $this->employee->status = 0;
        $this->employee->save();
        $this->message = "Employee Successfully Removed";
        $this->dispatchBrowserEvent('delete_show');
        $this->dispatchBrowserEvent('delete_swal');
    }
    public function activate()
    {
        $this->ref();
        $this->employee->status = 1;
        $this->employee->save();
        $this->message = "Employee Successfully Added";
        $this->dispatchBrowserEvent('activate_show');
        $this->dispatchBrowserEvent('active_swal');
    }
    public function service()
    {
        foreach ($this->a_services_selected as $s) {
            if ($s) {
                employee_service::create([
                    'user_id' => $this->employee->id,
                    'service_id' => $s
                ]);
            }
        }
        $this->ref();
        $this->message = "Employee Services Successfully Added";
        $this->dispatchBrowserEvent('services_show');
        $this->dispatchBrowserEvent('service_swal_add');
    }
    public function show_image($path)
    {
        $image = user::find($path);
        $this->path = $image->profile;
        $this->dispatchBrowserEvent('show_image');
    }
    public function specialty()
    {
        foreach ($this->a_specialties_selected as $s) {
            if ($s) {
                employee_specialty::create([
                    'user_id' => $this->employee->id,
                    'specialty_id' => $s
                ]);
            }
        }
        $this->ref();
        $this->message = "Employee Specialties Successfully Added";
        $this->dispatchBrowserEvent('specialties_show');
        $this->dispatchBrowserEvent('specialty_swal_add');
    }
    public function delete_specialty($id)
    {
        $specialty = employee_specialty::find($id);
        $specialty->delete();
        $this->ref();
        $this->message = "Employee Specialty Removed Successfully";
        $this->dispatchBrowserEvent('employee_show');
        $this->dispatchBrowserEvent('specialty_swal_delete');
    }
    public function delete_service($id)
    {
        $service = employee_service::find($id);
        $service->delete();
        $this->ref();
        $this->message = "Employee Service Removed Successfully";
        $this->dispatchBrowserEvent('employee_show');
        $this->dispatchBrowserEvent('service_swal_delete');
    }

    public function appointment_show()
    {
        $this->ref();
        $this->dispatchBrowserEvent('appointment_show');
    }

    public function appointment()
    {
        appointment::create([
            'user_id' => auth()->user()->id,
            'date' => $this->date,
            'status' => 1,
            'description' => $this->description,
        ]);
        $appointment = appointment::latest()->first();
        foreach ($this->selected_engineer as $e) {
            appointment_user::create([
                'user_id' => $e,
                'appointment_id' => $appointment->id,
            ]);
        }
        $this->ref();
        $this->selected_engineer = [];
        $this->message = "Appointment Set Successfully";
        $this->dispatchBrowserEvent('appointment_show');
        $this->dispatchBrowserEvent('appiontment_swal');
    }
}
