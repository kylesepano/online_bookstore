<?php

namespace App\Http\Controllers;

use App\Models\login_details;
use App\Models\user;
use App\Models\user_details;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function log(Request $request)
    {
        $this->validate($request, [
            'username' => 'required',
            'password' => 'required',
        ]);
        if (!auth()->attempt($request->only('username', 'password'), $request->remember)) {
            return back()->with('status', 'Invalid Login Details');
        }
        if (auth()->user()->status == 0) {
            auth()->logout();
            return back()->with('status', 'You are currently removed from the system please contact the company');
        }
        return redirect()->route('home');
    }
    public function reg(Request $request)
    {
        $this->validate($request, [
            'lname' => 'required|max:255',
            'mname' => 'required|max:255',
            'fname' => 'required|max:255',
            'username' => 'required|max:255|unique:users',
            'password' => 'required|confirmed|min:6',
        ]);
        user::create([
            'username' => $request->username,
            'password' => Hash::make($request->password),
            'user_type' => 4,
            'status' => 1,
            'lname' => $request->lname,
            'mname' => $request->mname,
            'fname' => $request->fname,
            'email' => null,
            'contact_number' => null,
            'address' => null,
            'profile' => 'uploads/profile/lala.png',
        ]);
        $lala = user::where('username', $request->username)->get()->first();
        auth()->attempt($request->only('username', 'password'));
        return redirect()->route('home');
    }
    public function logout()
    {
        auth()->logout();
        return redirect()->route('login');
    }
}
