<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    public function help($id)
    {
        return view('pages.help', ['id' => $id]);
    }
    public function appointment($id)
    {
        return view('pages.appointment', ['id' => $id]);
    }
}
